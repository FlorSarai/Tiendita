import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componenteuno',
  templateUrl: './componenteuno.component.html',
  styleUrls: ['./componenteuno.component.css']
})
export class ComponenteunoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
